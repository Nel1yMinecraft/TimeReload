package me.nelly;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class TimeReload extends JavaPlugin {
    private Map<Integer, TaskData> tasks = new HashMap<>();

    @Override
    public void onEnable() {
        getLogger().info("TimeReload by QQ 917752541 作者Nelly 接定制插件/Mod");
        // 注册命令
        getCommand("timereload").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "用法错误！用法: /timereload <createstart|delete|list/help> ...");
            return true;
        }

        String subCommand = args[0].toLowerCase();
        switch (subCommand) {
            case "help":
                sender.sendMessage(ChatColor.YELLOW + "TimeReload插件帮助--");
                sender.sendMessage(ChatColor.YELLOW + "/timereload createstart <任务编号 填数字> <是否循环 是为true 否为false> <要执行的指令 不需要/ 直接输入这种  \" kill sbplayer \"> <时间（分钟 填数字）>");
                sender.sendMessage(ChatColor.YELLOW + "/timereload delete <任务编号>");
            case "createstart":
                if (args.length < 4) {
                    sender.sendMessage(ChatColor.RED + "用法错误！用法: /timereload createstart <任务编号> <是否循环> <要执行的指令> [时间（分钟）]");
                    return true;
                }

                int taskId;
                try {
                    taskId = Integer.parseInt(args[1]);
                } catch (NumberFormatException e) {
                    sender.sendMessage(ChatColor.RED + "任务编号必须是数字！");
                    return true;
                }

                boolean isRepeating = Boolean.parseBoolean(args[2]);

                // 提取引号内的内容作为要执行的指令
                String commandToExecute = null;
                int index = 3;
                StringBuilder commandBuilder = new StringBuilder();
                while (index < args.length && (commandToExecute == null || commandToExecute.isEmpty())) {
                    String arg = args[index];
                    if (arg.startsWith("\"") && arg.endsWith("\"")) {
                        commandToExecute = arg.substring(1, arg.length() - 1);
                    } else if (arg.startsWith("\"")) {
                        commandBuilder.append(arg.substring(1)).append(" ");
                    } else if (arg.endsWith("\"")) {
                        commandBuilder.append(arg.substring(0, arg.length() - 1));
                        commandToExecute = commandBuilder.toString();
                    } else if (commandBuilder.length() > 0) {
                        commandBuilder.append(arg).append(" ");
                    }
                    index++;
                }
                if (commandToExecute == null || commandToExecute.isEmpty()) {
                    sender.sendMessage(ChatColor.RED + "未提供要执行的指令！");
                    return true;
                }

                int timeInMinutes = 0;
                if (index < args.length) {
                    try {
                        timeInMinutes = Integer.parseInt(args[index]);
                    } catch (NumberFormatException e) {
                        sender.sendMessage(ChatColor.RED + "时间必须是数字！");
                        return true;
                    }
                } else {
                    sender.sendMessage(ChatColor.RED + "未提供时间参数！");
                    return true;
                }

                TaskData taskData = new TaskData(commandToExecute, isRepeating, timeInMinutes);
                tasks.put(taskId, taskData);

                String finalCommandToExecute = commandToExecute;
                BukkitTask task = new BukkitRunnable() {
                    @Override
                    public void run() {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCommandToExecute);

                        if (!taskData.isRepeating()) {
                            tasks.remove(taskId);
                            cancel();
                        }
                    }
                }.runTaskTimer(this, 0L, timeInMinutes * 1200L); // 将分钟转换为游戏刻钟

                taskData.setTask(task);
                sender.sendMessage(ChatColor.GREEN + "成功创建并启动任务 " + taskId + " !");
                return true;



            case "delete":
                if (args.length != 2) {
                    sender.sendMessage(ChatColor.RED + "用法错误！用法: /timereload delete <任务编号>");
                    return true;
                }

                int deleteTaskId;
                try {
                    deleteTaskId = Integer.parseInt(args[1]);
                } catch (NumberFormatException e) {
                    sender.sendMessage(ChatColor.RED + "任务编号必须是数字！");
                    return true;
                }

                TaskData deleteTaskData = tasks.get(deleteTaskId);
                if (deleteTaskData == null) {
                    sender.sendMessage(ChatColor.RED + "未找到指定的任务！");
                    return true;
                }

                if (deleteTaskData.isRunning()) {
                    deleteTaskData.getTask().cancel();
                }

                tasks.remove(deleteTaskId);
                sender.sendMessage(ChatColor.GREEN + "任务 " + deleteTaskId + " 已删除！");
                return true;

            case "list":
                sender.sendMessage(ChatColor.GREEN + "任务列表:");

                for (Map.Entry<Integer, TaskData> entry : tasks.entrySet()) {

                    sender.sendMessage(ChatColor.YELLOW + "任务编号: " + entry.getKey());
                    sender.sendMessage(ChatColor.YELLOW + "是否循环: " + (entry.getValue().isRepeating() ? "是" : "否"));
                    sender.sendMessage(ChatColor.YELLOW + "要执行的指令: " + entry.getValue().getCommand());
                    sender.sendMessage(ChatColor.YELLOW + "时间（分钟）: " + entry.getValue().getTimeInMinutes());
                    sender.sendMessage("");
                }

                return true;

            default:
                sender.sendMessage(ChatColor.RED + "未知的子命令！用法: /timereload <createstart|delete|list> ...");
                return true;
        }
    }

}
