package me.nelly;

import org.bukkit.scheduler.BukkitTask;

public class TaskData {
    private String command;
    private boolean isRepeating;
    private int timeInMinutes;
    private BukkitTask task;
    private String commandToExecute;

    public TaskData(String command, boolean isRepeating, int timeInMinutes) {
        this.command = command;
        this.isRepeating = isRepeating;
        this.timeInMinutes = timeInMinutes;
    }

    public String getCommand() {
        return command;
    }

    public boolean isRepeating() {
        return isRepeating;
    }
    
    public int getTimeInMinutes() {
        return timeInMinutes;
    }
    
    public boolean isRunning() {
        return task != null && !task.isCancelled();
    }
    
    public BukkitTask getTask() {
        return task;
    }
    
    public void setTask(BukkitTask task) {
        this.task = task;
    }
}
